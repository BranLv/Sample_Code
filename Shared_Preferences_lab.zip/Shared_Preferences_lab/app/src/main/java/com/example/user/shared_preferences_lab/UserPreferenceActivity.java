package com.example.user.shared_preferences_lab;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by user on 5/2/2018.
 */

public class UserPreferenceActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        getFragmentManager().beginTransaction()
                .replace(android.R.id.content, new UserPreferenceFragment())
                .commit();


    }

}
