package com.example.user.shared_preferences_lab;

import android.os.Bundle;
import android.preference.PreferenceFragment;

/**
 * Created by user on 5/2/2018.
 */

public class UserPreferenceFragment extends PreferenceFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        addPreferencesFromResource(R.xml.preferences);

    }
}
